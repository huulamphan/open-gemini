package com.example.geminivoice;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

/**
 * Bấm icon là mở trợ lý giọng nói ngay, rồi tự đóng.
 * Thứ tự thử:
 *  1. Lệnh "voice command" của hệ thống -> mở trợ lý mặc định (Gemini nếu bạn đã đặt Gemini làm trợ lý số).
 *  2. Nếu không được, mở thẳng app Gemini.
 */
public class MainActivity extends Activity {

    private static final String GEMINI_PACKAGE = "com.google.android.apps.bard";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        openGeminiVoice();
        finish();
    }

    private void openGeminiVoice() {
        // Cách 1: trợ lý giọng nói mặc định
        try {
            Intent voice = new Intent(Intent.ACTION_VOICE_COMMAND);
            voice.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(voice);
            return;
        } catch (ActivityNotFoundException | SecurityException ignored) {
            // thử cách 2
        }

        // Cách 2: mở app Gemini
        Intent launch = getPackageManager().getLaunchIntentForPackage(GEMINI_PACKAGE);
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
            return;
        }

        Toast.makeText(this, R.string.gemini_not_found, Toast.LENGTH_LONG).show();
    }
}
